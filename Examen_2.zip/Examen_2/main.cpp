#include <iostream>
#include <string.h>
#include <string>
#include <conio.h>
#include<windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctime>


/* run this program using the console pauser or add your own getch, system("pause") or input loop */


	using namespace std;
	//constantes de los partidosy candidatos
	string PartidosPoliticos[]={"PAC","PUSC","PLN","PAN","PRD","FA"};
	const int _longitudArray=(sizeof PartidosPoliticos / sizeof PartidosPoliticos[0]);
	string nombreCandidato[_longitudArray]={""};
	int cod_Partido_Pol[_longitudArray]={0};
	string PartidoEscogido[]={""};
	
	//constantes de los votos
	string ID_Votante[50]={""};
	string NombreVotante[50]={""};
	int Reg_votos[50]={0};
	const int _longitudArrayIdCand=(sizeof cod_Partido_Pol/ sizeof cod_Partido_Pol[0]);
	int ID_CandVotado[_longitudArrayIdCand]={0};
	int ContadorCandVotado[]={0};
	

		/*		+++++++++++++	  	SECCION  "1" CANDIDATOS		+++++++++++++*/
	string muestraID_Partidos(int ingresado){
			int _longitudCodCand=(sizeof cod_Partido_Pol / sizeof cod_Partido_Pol[0]);
			int i=0;
			string repetido="";
			while(i<_longitudCodCand){				
				
				if(ingresado==cod_Partido_Pol[i]){
					string repetido="";
					cout<<"Candidato repetido, ingrese otro candidato";
					break;
				}
				if(ingresado!=cod_Partido_Pol[i] && cod_Partido_Pol[i]==0){					
					repetido="No";
					cout<<endl<<"Datos ingresado con �xito!!"<<endl;
					break;					
				}				
			i++;
			}
		
		return repetido;			
	}
	
	
	
	void Ingresar_Candidato(){
		setlocale(LC_ALL, "");
		system("cls");
		int ContadorCandidato=0;
		int CodPartidoIngresado=0;
		char eleccion;
		int contador=0;
		int LongitudArray_Partidos=0;
		LongitudArray_Partidos=sizeof PartidosPoliticos / sizeof PartidosPoliticos[0];
		

		do{
			system("cls");
			printf("\n\n ++++++++++++++++++++++++++++++++++++++++++++++++++");
			printf("\n\tINGRESO DE CANDIDATOS ");
			printf(" \n++++++++++++++++++++++++++++++++++++++++++++++++++\n");
			printf("\n\tLista de partidos politicos ");
			printf(" \n++++++++++++++++++++++++++++++++++++++++++++++++++\n\n");
			cout<<"\t";			
			for(int i=1;i <=LongitudArray_Partidos;i++){
				cout<<i<<"."<<PartidosPoliticos[i-1]<<"  ";
			}
			printf(" \n_____________________________________________________\n\n");
						
			printf("\n\nNombre del candidato: ");
			fflush(stdin);
			getline(cin,nombreCandidato[ContadorCandidato]);//lee una linea completa y lo guarda en el vector de string			
		    fflush(stdin);
		    printf("\nEscoja el Partido pol�tico: ");
		    cin>>CodPartidoIngresado;		  
		    fflush(stdin);
		    //--------------------
		    if(muestraID_Partidos(CodPartidoIngresado)=="No"){	// valida la repeticion a la hora de ingresar un candidato
		    	cod_Partido_Pol[ContadorCandidato]=CodPartidoIngresado;
		    	ContadorCandidato++;
			}
	
			contador++;
	
			cout<<"\n �desea ingresar m�s candidatos? (s/n): ";	
			cin>>eleccion;
			fflush(stdin);
			if (eleccion=='n'||eleccion=='N'){	
				break;
			}	
		}while(eleccion!='n');	
		
	}
	

	string ValidaCandidato(int ingresado){	//valida que exista el candidato a la hora de votar
			int _longitudCodCand=(sizeof cod_Partido_Pol / sizeof cod_Partido_Pol[0]);
			int i=0;
			string ValidaCandidato="";
						
			while(i<_longitudCodCand){				
				
				if(ingresado==0){					
				ValidaCandidato="NO";
				cout<<"Candidato no existe,elija candidato de la lista";
				break;
				}
				
				if(ingresado==cod_Partido_Pol[i]){
					
					ValidaCandidato="EXISTE";
					cout<<endl<<"Voto realizado!!"<<endl;
					break;
				}						
			i++;
			}
			
				if( ValidaCandidato==""){					
					ValidaCandidato="NO";
					cout<<"Candidato no existe,elija candidato de la lista";					
				}	
		
		return ValidaCandidato;	
	}
	
		/*		+++++++++++++	  	SECCION  "2" VOTACIONES		+++++++++++++*/
		
		
	int ValidaMinimoCandidatos(){
		int _longitudPartidos=(sizeof PartidosPoliticos / sizeof PartidosPoliticos[0]);
		int ContadorMinimoCand=0;	
			for(int i=0;i<_longitudPartidos;i++){
				
				if(cod_Partido_Pol[i]>0){
					ContadorMinimoCand++;
				}
			}
			
		return ContadorMinimoCand;
	}
		
	void MuestraCandidatos(){
		for(int i=0;i<_longitudArray;i++){
			if(cod_Partido_Pol[i]>0){
				cout<<"\t"<<cod_Partido_Pol[i]<<": ";
				cout<<"\t"<<PartidosPoliticos[cod_Partido_Pol[i]-1]<<".";
				cout<<"\t"<<nombreCandidato[i]<<endl;
			//	ID_CandVotado[i]=cod_Partido_Pol[i];
				
			}	
		}	
	}
	
	int contadorVotos[]={0};
	
	void ContadorVotos(int votoIngresado){
	  int contador=0;
	  int _longitudCodPartido=(sizeof Reg_votos/ sizeof Reg_votos[0]);
	
		for(int i=0;i<_longitudCodPartido;i++){
			
			if(ID_CandVotado[i]>0){
				
				if(ID_CandVotado[i]==votoIngresado ){
				
		
				}	
			}
			
		}	
		//Reg_votos		
	}
	
	void Votaciones(){
		setlocale(LC_ALL, "");
		int ContadorVotante=0;
		int VotoIngresado=0;
		char eleccion;
		int LongitudArray_Partidos=0;
		LongitudArray_Partidos=sizeof PartidosPoliticos / sizeof PartidosPoliticos[0];
	
		do{
			system("cls");
			printf("\n\n <<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>");
			printf("\n\tSALA DE VOTACIONES ");
			printf(" \n<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>\n");
			printf("\n\tLista de candidatos y sus partidos");
			printf(" \n________________________________________________\n\n");		
			MuestraCandidatos();			
			printf(" \n_____________________________________________________\n\n");
			
			if(ValidaMinimoCandidatos()==0){
				cout<<"No hay Candidatos para votar... "<<endl<<"Ingrese los candidatos y luego proceda a votar";
				break;
			}
						
			printf("\nIngrese el numero de c�dula: ");
			fflush(stdin);
			getline(cin,ID_Votante[ContadorVotante]);//lee una linea completa y lo guarda en el vector de string			
		    fflush(stdin);
		    
		    printf("\nIngrese su nombre: ");
			fflush(stdin);
			getline(cin,NombreVotante[ContadorVotante]);//lee una linea completa y lo guarda en el vector de string			
		    fflush(stdin);
		    
		    printf("\nElija una opci�n para votar: ");
		    cin>>VotoIngresado;		  
		    fflush(stdin);
		    //--------------------
		    
		    if(ValidaCandidato(VotoIngresado)=="EXISTE"){//valida que el candidato exista
			
		    	Reg_votos[ContadorVotante]=VotoIngresado;
		    	ContadorVotante++;

			}
	
			cout<<"\n �Desea ingresar m�s votantes? (s/n): ";	
			cin>>eleccion;
			fflush(stdin);
			if (eleccion=='n'){	
		
				break;
			}	
			
		}while(eleccion!='n');			
	}
	
		/*		+++++++++++++	  	SECCION  "3" RESULTADOS DE LAS VOTACIONES		+++++++++++++*/	
		
	void SeccionResultados(){
		
			
		system("cls");
			printf("\n\n =================================================");
			printf("\n\tRESULTADO DE LAS VOTACIONES ");
			printf(" \n=================================================\n");
			
			cout<<"Registro de votos\n";
		
		int Longitud_RegVotos=sizeof Reg_votos / sizeof Reg_votos[0];
			
		for(int i=0;i<_longitudArray;i++){
			int Mayor=0;
			int contadorVotos=0;
			if(cod_Partido_Pol[i]>0){
				
				cout<<"\t"<<cod_Partido_Pol[i]<<": ";
				cout<<"\t"<<PartidosPoliticos[cod_Partido_Pol[i]-1]<<".";
				cout<<"\t"<<nombreCandidato[i];
				
				for(int j=0;j<Longitud_RegVotos;j++)	
				{
					if(cod_Partido_Pol[i]==Reg_votos[j]){
						contadorVotos++;
					}
					
				}
					
				cout<<"\t cantidad de votos: "<<contadorVotos<<endl;				
			}	
		}
			
		printf(" \n________________________________________________\n\n");				
	}

	void Menu(){
			setlocale(LC_ALL, "");
		int op;
		do{			
			system("cls");
			printf("\n==========================================");
			printf("\nSISTEMA DE VOTACIONES\n");
			printf("==========================================\n\n\n\n");			
			printf("-Opcion 1: Ingresar Candidatos\n");
			printf("-Opcion 2: Votaciones\n");
			printf("-Opcion 3: Resultados\n");
			printf("-Opcion 4: Salir\n");
			printf("\nDigite una opci�n: ");
			scanf("%i",&op);
			
			switch (op)
			{
				case 1:
					Ingresar_Candidato();
				break;
				case 2:
					Votaciones();
					getch();
				break;
				case 3:	
					SeccionResultados();
					getch();				
				break;
				case 4:					
				break;
			}
		
		}while(op!=4);						
	}

int main(int argc, char** argv) {
	Menu();
	return 0;
}
