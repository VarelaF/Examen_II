#include <iostream>
#include <string.h>
#include <string>
#include <conio.h>
#include<windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctime>


/* run this program using the console pauser or add your own getch, system("pause") or input loop */


	using namespace std;

	string PartidosPoliticos[]={"PAC","PUSC","PLN","PAN","PRD","FA"};
	const int _longitudArray=(sizeof PartidosPoliticos / sizeof PartidosPoliticos[0]);
	string nombreCandidato[_longitudArray]={""};
	int cod_Partido_Pol[_longitudArray]={0};
	string PartidoEscogido[]={""};
	

		/*		+++++++++++++	  	SECCION  "1" CANDIDATOS		+++++++++++++*/
	string muestraID_Partidos(int ingresado){
			int _longitudCodCand=(sizeof cod_Partido_Pol / sizeof cod_Partido_Pol[0]);
			int i=0;
			string repetido="";
			while(i<_longitudCodCand){				
				
				if(ingresado==cod_Partido_Pol[i]){
					string repetido="";
					cout<<"Candidato repetido, ingrese otro candidato";
					break;
				}
				if(ingresado!=cod_Partido_Pol[i] && cod_Partido_Pol[i]==0){					
					repetido="No";
					cout<<endl<<"Datos ingresado con �xito!!"<<endl;
					break;					
				}				
			i++;
			}
		
		return repetido;			
	}
	
	
	
	void Ingresar_Candidato(){
		setlocale(LC_ALL, "");
		system("cls");
		int ContadorCandidato=0;
		int CodPartidoIngresado=0;
		char eleccion;
		int contador=0;
		int LongitudArray_Partidos=0;
		LongitudArray_Partidos=sizeof PartidosPoliticos / sizeof PartidosPoliticos[0];
		

		do{
			system("cls");
			printf("\n\n ++++++++++++++++++++++++++++++++++++++++++++++++++");
			printf("\n\tINGRESO DE CANDIDATOS ");
			printf(" \n++++++++++++++++++++++++++++++++++++++++++++++++++\n");
			printf("\n\tLista de partidos politicos ");
			printf(" \n++++++++++++++++++++++++++++++++++++++++++++++++++\n\n");
			cout<<"\t";			
			for(int i=1;i <=LongitudArray_Partidos;i++){
				cout<<i<<"."<<PartidosPoliticos[i-1]<<"  ";
			}
			printf(" \n_____________________________________________________\n\n");
						
			printf("\n\nNombre del candidato: ");
			fflush(stdin);
			getline(cin,nombreCandidato[ContadorCandidato]);//lee una linea completa y lo guarda en el vector de string			
		    fflush(stdin);
		    printf("\nEscoja el Partido pol�tico: ");
		    cin>>CodPartidoIngresado;		  
		    fflush(stdin);
		    //--------------------
		    if(muestraID_Partidos(CodPartidoIngresado)=="No"){
		    	cod_Partido_Pol[ContadorCandidato]=CodPartidoIngresado;
		    	ContadorCandidato++;
			}
	
			contador++;
	
			cout<<"\n �desea ingresar m�s candidatos? (s/n): ";	
			cin>>eleccion;
			fflush(stdin);
			if (eleccion=='n'){	
				break;
			}	
		}while(eleccion!='n');	
		
		//getch();			
	}
	

	string ValidaCandidato(int ingresado){
			int _longitudCodCand=(sizeof cod_Partido_Pol / sizeof cod_Partido_Pol[0]);
			int i=0;
			string ValidaCandidato="";
			while(i<_longitudCodCand){				
				
				if(ingresado==cod_Partido_Pol[i]){
					string ValidaCandidato="";
					cout<<"Candidato repetido, ingrese otro candidato";
					break;
				}
				if(ingresado!=cod_Partido_Pol[i] && cod_Partido_Pol[i]==0){					
					ValidaCandidato="No";
					cout<<endl<<"No existe, vuelva a botar!!"<<endl;
					break;					
				}				
			i++;
			}
		
		return ValidaCandidato;	
	}
	
		/*		+++++++++++++	  	SECCION  "2" VOTACIONES		+++++++++++++*/
	
	
	void MuestraCandidatos(){

		for(int i=0;i<_longitudArray;i++){
			if(cod_Partido_Pol[i]>0){
				cout<<"\t"<<cod_Partido_Pol[i]<<": ";
				cout<<"\t"<<PartidosPoliticos[cod_Partido_Pol[i]-1]<<".";
				cout<<"\t"<<nombreCandidato[i]<<endl;
			}
			
		}
	
	
	}
	
	string ID_Votante[]={""};
	string NombreVotante[]={""};
	int Reg_votos[]={0};
	
	void Votaciones(){
		setlocale(LC_ALL, "");
		system("cls");
		int ContadorVotante=0;
		int VotoIngresado=0;
		char eleccion;
		int contador=0;
		int LongitudArray_Partidos=0;
		LongitudArray_Partidos=sizeof PartidosPoliticos / sizeof PartidosPoliticos[0];
					
		do{
			system("cls");
			printf("\n\n <<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>");
			printf("\n\tSALA DE VOTACIONES ");
			printf(" \n<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>\n");
			printf("\n\tLista de candidatos y sus partidos");
			printf(" \n________________________________________________\n\n");		
			MuestraCandidatos();			
			printf(" \n_____________________________________________________\n\n");
						
			printf("\nIngrese el numero de c�dula: ");
			fflush(stdin);
			getline(cin,ID_Votante[ContadorVotante]);//lee una linea completa y lo guarda en el vector de string			
		    fflush(stdin);
		    
		    printf("\nIngrese su nombre: ");
			fflush(stdin);
			getline(cin,NombreVotante[ContadorVotante]);//lee una linea completa y lo guarda en el vector de string			
		    fflush(stdin);
		    
		    printf("\nElija una opci�n para votar: ");
		    cin>>VotoIngresado;		  
		    fflush(stdin);
		    //--------------------
		    
		    if(ValidaCandidato(VotoIngresado)=="No"){
		    	cod_Partido_Pol[ContadorVotante]=VotoIngresado;
		    	ContadorVotante++;
			}
	
			contador++;
	
			cout<<"\n �desea ingresar m�s votantes? (s/n): ";	
			cin>>eleccion;
			fflush(stdin);
			if (eleccion=='n'){	
				break;
			}	
		}while(eleccion!='n');	
		
		
		getch();			
		
		
	}

	void Menu(){
			setlocale(LC_ALL, "");
		int op;
		do{			
			system("cls");
			printf("\n==========================================");
			printf("\nSISTEMA DE VOTACIONES\n");
			printf("==========================================\n\n\n\n");			
			printf("-Opcion 1: Ingresar Candidatos\n");
			printf("-Opcion 2: Votaciones\n");
			printf("-Opcion 3: Resultados\n");
			printf("-Opcion 4: Salir\n");
			printf("\nDigite una opci�n: ");
			scanf("%i",&op);
			
			switch (op)
			{
				case 1:
					Ingresar_Candidato();
				break;
				case 2:
					Votaciones();
					getch();
				break;
				case 3:					
				break;
			}
		
		}while(op!=4);						
	}

int main(int argc, char** argv) {
	Menu();
	return 0;
}
